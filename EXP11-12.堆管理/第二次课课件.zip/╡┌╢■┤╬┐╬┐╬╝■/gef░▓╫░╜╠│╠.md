## GEF更新教程

1. 下载**gef.py**

2. 将下载好的**gef.py**通过共享文件夹放到**/home/ubuntu/**下

3. 使用命令**`sudo rm /home/ubuntu/.gdbinit /root/.gdbinit`**删除旧版本的gef

4. 使用命令**`sudo echo source /home/ubuntu/gef.py >> /home/ubuntu/.gdbinit`**和

   **`sudo echo source /home/ubuntu/gef.py >> /root/.gdbinit`**安装新版本的gef后即可正常使用。

## 安装tmux

使用命令**`sudo apt install tmux`**安装**tmux**

