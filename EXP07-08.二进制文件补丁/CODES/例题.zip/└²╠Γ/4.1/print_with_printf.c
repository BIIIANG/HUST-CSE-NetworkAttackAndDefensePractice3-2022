#include <stdio.h>

int main() {
	printf("test2.1");
	char s[10];
	scanf("%s", s);
	printf(s);
	return 0;
}
