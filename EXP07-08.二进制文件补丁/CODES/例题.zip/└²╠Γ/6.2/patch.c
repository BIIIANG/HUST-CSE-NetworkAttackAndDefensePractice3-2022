#include <stdio.h>
 
int newprintf()
{
    puts("My student number is xxx.");
    return 0;
}