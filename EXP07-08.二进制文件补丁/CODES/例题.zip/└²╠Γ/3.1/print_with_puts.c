#include<stdio.h>

int main() {
	puts("test1");
	char s[20];
	scanf("%s", s);
	printf(s);
	return 0;
}
